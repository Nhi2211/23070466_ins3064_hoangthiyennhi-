-- =====================================================================
-- Online Bookstore Database  (MySQL 8.0.16+ / InnoDB / utf8mb4)
-- Run with:  source bookstore_db.sql
-- NOTE: CHECK constraints are only enforced from MySQL 8.0.16 onward.
-- =====================================================================

/* =====================================================================
   NORMALIZATION EXPLANATION (how this design achieves 3NF)
   ---------------------------------------------------------------------
   1NF - Every column holds one atomic value and there are no repeating
         groups. A book's several authors are NOT stored as "A, B" in a
         column; they are rows in book_authors. Likewise categories
         live in book_categories, and an order's products live in
         order_items (one row per book per order).

   2NF - Every non-key attribute depends on the WHOLE primary key.
         Junction tables book_authors(book_id, author_id) and
         book_categories(book_id, category_id) have a composite key and
         carry no attributes about just one half of the key (the only
         extra column, author_order, depends on the pair). order_items
         uses a surrogate key plus UNIQUE(order_id, book_id); quantity
         and unit_price depend on the (order, book) pair as a whole.

   3NF - No non-key attribute depends on another non-key attribute.
         * Publisher data (name, address, website) lives in publishers,
           not repeated in books; books stores only publisher_id.
         * Author data lives in authors; category data in categories
           (hierarchy via parent_category_id, no duplicated parent info).
         * Customer details live in customers; orders stores only
           customer_id, not the customer's name or email.
         * order_items.subtotal is a GENERATED column (quantity *
           unit_price), so it can never become inconsistent.

   Deliberate, documented design choices (snapshots, not redundancy):
         * order_items.unit_price records the price AT PURCHASE TIME.
           It differs from books.price over time, so it is its own fact.
         * orders.ship_* columns store the address used for THAT order.
           A customer may move later; history must not change.
         * orders.total_amount is a stored snapshot of the order total
           (required by the assignment). It must equal the sum of that
           order's order_items.subtotal; the sample data respects this.
           A stricter alternative is to drop it and compute it by query/view.
         * customers keeps city/state/postal_code together as one address
           block; splitting out a zip-code lookup table would be
           over-engineering for this domain.
   ===================================================================== */

DROP DATABASE IF EXISTS bookstore_db;
CREATE DATABASE bookstore_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE bookstore_db;

-- ---------------------------------------------------------------------
-- 1. authors
-- ---------------------------------------------------------------------
CREATE TABLE authors (
    author_id    INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    first_name   VARCHAR(60)   NOT NULL,
    last_name    VARCHAR(60)   NOT NULL,
    biography    TEXT          NULL,
    nationality  VARCHAR(60)   NULL,
    birth_date   DATE          NULL,
    PRIMARY KEY (author_id),
    INDEX idx_authors_name (last_name, first_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 2. publishers
-- ---------------------------------------------------------------------
CREATE TABLE publishers (
    publisher_id INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    name         VARCHAR(120)  NOT NULL,
    street       VARCHAR(150)  NULL,
    city         VARCHAR(80)   NULL,
    country      VARCHAR(80)   NULL,
    website      VARCHAR(255)  NULL,
    PRIMARY KEY (publisher_id),
    UNIQUE KEY uq_publishers_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 3. categories (self-referencing for sub-genres)
-- ---------------------------------------------------------------------
CREATE TABLE categories (
    category_id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name               VARCHAR(80)  NOT NULL,
    description        TEXT         NULL,
    parent_category_id INT UNSIGNED NULL,
    PRIMARY KEY (category_id),
    UNIQUE KEY uq_categories_name (name),
    CONSTRAINT fk_categories_parent
        FOREIGN KEY (parent_category_id) REFERENCES categories (category_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 4. books
-- ---------------------------------------------------------------------
CREATE TABLE books (
    book_id          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    isbn             CHAR(13)      NOT NULL,
    title            VARCHAR(200)  NOT NULL,
    publisher_id     INT UNSIGNED  NOT NULL,
    price            DECIMAL(8,2)  NOT NULL,
    stock            INT           NOT NULL DEFAULT 0,
    publication_date DATE          NULL,
    pages            SMALLINT UNSIGNED NULL,
    language         VARCHAR(30)   NOT NULL DEFAULT 'English',
    description      TEXT          NULL,
    created_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (book_id),
    UNIQUE KEY uq_books_isbn (isbn),
    INDEX idx_books_title (title),
    CONSTRAINT chk_books_price CHECK (price > 0),
    CONSTRAINT chk_books_stock CHECK (stock >= 0),
    CONSTRAINT fk_books_publisher
        FOREIGN KEY (publisher_id) REFERENCES publishers (publisher_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 5. book_authors  (M:N books <-> authors)
-- ---------------------------------------------------------------------
CREATE TABLE book_authors (
    book_id      INT UNSIGNED NOT NULL,
    author_id    INT UNSIGNED NOT NULL,
    author_order TINYINT UNSIGNED NOT NULL DEFAULT 1,  -- 1 = primary author
    PRIMARY KEY (book_id, author_id),
    INDEX idx_ba_author (author_id),
    CONSTRAINT fk_ba_book
        FOREIGN KEY (book_id) REFERENCES books (book_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ba_author
        FOREIGN KEY (author_id) REFERENCES authors (author_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 6. book_categories  (M:N books <-> categories)
-- ---------------------------------------------------------------------
CREATE TABLE book_categories (
    book_id     INT UNSIGNED NOT NULL,
    category_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (book_id, category_id),
    INDEX idx_bc_category (category_id),
    CONSTRAINT fk_bc_book
        FOREIGN KEY (book_id) REFERENCES books (book_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_bc_category
        FOREIGN KEY (category_id) REFERENCES categories (category_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 7. customers
-- ---------------------------------------------------------------------
CREATE TABLE customers (
    customer_id   INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    first_name    VARCHAR(60)   NOT NULL,
    last_name     VARCHAR(60)   NOT NULL,
    email         VARCHAR(190)  NOT NULL,
    password_hash VARCHAR(255)  NOT NULL,
    phone         VARCHAR(25)   NULL,
    street        VARCHAR(150)  NULL,
    city          VARCHAR(80)   NULL,
    state         VARCHAR(80)   NULL,
    postal_code   VARCHAR(20)   NULL,
    country       VARCHAR(80)   NULL,
    created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (customer_id),
    UNIQUE KEY uq_customers_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 8. orders
-- ---------------------------------------------------------------------
CREATE TABLE orders (
    order_id         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    customer_id      INT UNSIGNED  NOT NULL,
    order_date       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status           ENUM('pending','processing','shipped','delivered','cancelled')
                                   NOT NULL DEFAULT 'pending',
    total_amount     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    ship_street      VARCHAR(150)  NOT NULL,
    ship_city        VARCHAR(80)   NOT NULL,
    ship_state       VARCHAR(80)   NULL,
    ship_postal_code VARCHAR(20)   NOT NULL,
    ship_country     VARCHAR(80)   NOT NULL,
    PRIMARY KEY (order_id),
    INDEX idx_orders_customer (customer_id),
    INDEX idx_orders_date (order_date),
    CONSTRAINT chk_orders_total CHECK (total_amount >= 0),
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 9. order_items
-- ---------------------------------------------------------------------
CREATE TABLE order_items (
    order_item_id INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    order_id      INT UNSIGNED  NOT NULL,
    book_id       INT UNSIGNED  NOT NULL,
    quantity      INT UNSIGNED  NOT NULL DEFAULT 1,
    unit_price    DECIMAL(8,2)  NOT NULL,
    subtotal      DECIMAL(10,2) AS (quantity * unit_price) STORED,
    PRIMARY KEY (order_item_id),
    UNIQUE KEY uq_order_book (order_id, book_id),
    INDEX idx_oi_book (book_id),
    CONSTRAINT chk_oi_quantity CHECK (quantity > 0),
    CONSTRAINT chk_oi_price    CHECK (unit_price > 0),
    CONSTRAINT fk_oi_order
        FOREIGN KEY (order_id) REFERENCES orders (order_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_oi_book
        FOREIGN KEY (book_id) REFERENCES books (book_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 10. reviews
-- ---------------------------------------------------------------------
CREATE TABLE reviews (
    review_id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    book_id     INT UNSIGNED NOT NULL,
    customer_id INT UNSIGNED NOT NULL,
    rating      TINYINT      NOT NULL,
    comment     TEXT         NULL,
    review_date DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (review_id),
    UNIQUE KEY uq_review_customer_book (customer_id, book_id),
    INDEX idx_reviews_book (book_id),
    CONSTRAINT chk_reviews_rating CHECK (rating BETWEEN 1 AND 5),
    CONSTRAINT fk_reviews_book
        FOREIGN KEY (book_id) REFERENCES books (book_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_customer
        FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- SAMPLE DATA
-- =====================================================================

-- Publishers (4)
INSERT INTO publishers (publisher_id, name, street, city, country, website) VALUES
(1, 'Penguin Random House', '1745 Broadway', 'New York', 'USA', 'https://www.penguinrandomhouse.com'),
(2, 'HarperCollins', '195 Broadway', 'New York', 'USA', 'https://www.harpercollins.com'),
(3, 'O''Reilly Media', '1005 Gravenstein Hwy N', 'Sebastopol', 'USA', 'https://www.oreilly.com'),
(4, 'Bloomsbury Publishing', '50 Bedford Square', 'London', 'United Kingdom', 'https://www.bloomsbury.com');

-- Authors (9; some books have two authors)
INSERT INTO authors (author_id, first_name, last_name, biography, nationality, birth_date) VALUES
(1, 'Frank',  'Herbert',  'American writer best known for the Dune series.', 'American', '1920-10-08'),
(2, 'William','Gibson',   'Pioneer of the cyberpunk genre.', 'American-Canadian', '1948-03-17'),
(3, 'J.R.R.', 'Tolkien',  'English author and philologist; creator of Middle-earth.', 'British', '1892-01-03'),
(4, 'J.K.',   'Rowling',  'British author of the Harry Potter series.', 'British', '1965-07-31'),
(5, 'Martin', 'Kleppmann','Researcher and author on distributed systems and data.', 'British', NULL),
(6, 'Yuval Noah', 'Harari','Israeli historian and professor at the Hebrew University.', 'Israeli', '1976-02-24'),
(7, 'Terry',  'Pratchett','English humorist and fantasy author (Discworld).', 'British', '1948-04-28'),
(8, 'Neil',   'Gaiman',   'English author of novels, comics and screenplays.', 'British', '1960-11-10'),
(9, 'Alan',   'Beaulieu', 'Author and database consultant.', 'American', NULL);

-- Categories (5; two sub-genres under Fiction)
INSERT INTO categories (category_id, name, description, parent_category_id) VALUES
(1, 'Fiction',         'Imaginative narrative works.', NULL),
(2, 'Science Fiction', 'Speculative fiction based on science and technology.', 1),
(3, 'Fantasy',         'Fiction featuring magic and supernatural elements.', 1),
(4, 'Non-Fiction',     'Factual and informational works.', NULL),
(5, 'Technology',      'Computing, databases and software engineering.', NULL);

-- Books (8)
INSERT INTO books (book_id, isbn, title, publisher_id, price, stock, publication_date, pages, language, description) VALUES
(1, '9780441172719', 'Dune', 1, 14.99, 40, '1965-08-01', 688, 'English', 'Epic science fiction saga set on the desert planet Arrakis.'),
(2, '9780441569595', 'Neuromancer', 1, 13.99, 25, '1984-07-01', 271, 'English', 'Landmark cyberpunk novel.'),
(3, '9780547928227', 'The Hobbit', 2, 12.99, 60, '1937-09-21', 300, 'English', 'Bilbo Baggins joins a quest to reclaim a dwarf kingdom.'),
(4, '9781408855652', 'Harry Potter and the Philosopher''s Stone', 4, 11.50, 80, '1997-06-26', 336, 'English', 'A boy discovers he is a wizard.'),
(5, '9780596520830', 'Learning SQL', 3, 39.99, 30, '2009-04-21', 336, 'English', 'Practical introduction to SQL.'),
(6, '9781449373320', 'Designing Data-Intensive Applications', 3, 59.99, 20, '2017-03-16', 616, 'English', 'Principles behind reliable, scalable data systems.'),
(7, '9780062316097', 'Sapiens: A Brief History of Humankind', 2, 18.99, 35, '2015-02-10', 464, 'English', 'A history of the human species.'),
(8, '9780060853983', 'Good Omens', 2, 15.99, 28, '2006-11-28', 400, 'English', 'Comic fantasy about the coming Apocalypse.');

-- book_authors (M:N)
INSERT INTO book_authors (book_id, author_id, author_order) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 9, 1),
(6, 5, 1),
(7, 6, 1),
(8, 7, 1),
(8, 8, 2);

-- book_categories (M:N)
INSERT INTO book_categories (book_id, category_id) VALUES
(1, 1), (1, 2),
(2, 1), (2, 2),
(3, 1), (3, 3),
(4, 1), (4, 3),
(5, 5),
(6, 5), (6, 4),
(7, 4),
(8, 1), (8, 3);

-- Customers (5)  (password hashes are dummy bcrypt-style strings)
INSERT INTO customers (customer_id, first_name, last_name, email, password_hash, phone, street, city, state, postal_code, country, created_at) VALUES
(1, 'Linh',  'Nguyen',  'linh.nguyen@example.com',  '$2b$12$abcdefghijklmnopqrstuuK1m2n3o4p5q6r7s8t9u0v1w2x3y4z5A', '+84 912 345 678', '12 Nguyen Trai',     'Hanoi',    NULL,   '100000', 'Vietnam', '2026-01-10 09:15:00'),
(2, 'Minh',  'Tran',    'minh.tran@example.com',    '$2b$12$bcdefghijklmnopqrstuvuL2n3o4p5q6r7s8t9u0v1w2x3y4z5A6B', '+84 903 222 111', '45 Le Loi',          'Da Nang',  NULL,   '550000', 'Vietnam', '2026-02-03 14:30:00'),
(3, 'Emma',  'Johnson', 'emma.johnson@example.com', '$2b$12$cdefghijklmnopqrstuvwvM3o4p5q6r7s8t9u0v1w2x3y4z5A6B7C', '+1 415 555 0134',  '221 Market St',      'San Francisco', 'CA', '94105', 'USA', '2026-02-20 18:05:00'),
(4, 'Oliver','Smith',   'oliver.smith@example.com', '$2b$12$defghijklmnopqrstuvwxwN4p5q6r7s8t9u0v1w2x3y4z5A6B7C8D', '+44 20 7946 0958','10 Baker Street',    'London',   NULL,   'NW1 6XE', 'United Kingdom', '2026-03-15 11:45:00'),
(5, 'Sofia', 'Garcia',  'sofia.garcia@example.com', '$2b$12$efghijklmnopqrstuvwxyxO5q6r7s8t9u0v1w2x3y4z5A6B7C8D9E', '+34 91 123 4567', 'Calle Mayor 8',      'Madrid',   NULL,   '28013', 'Spain', '2026-04-02 08:20:00');

-- Orders (6). total_amount = SUM(order_items.subtotal) for each order.
INSERT INTO orders (order_id, customer_id, order_date, status, total_amount, ship_street, ship_city, ship_state, ship_postal_code, ship_country) VALUES
(1, 1, '2026-05-02 10:00:00', 'delivered',  28.98, '12 Nguyen Trai', 'Hanoi',   NULL, '100000', 'Vietnam'),
(2, 2, '2026-05-10 15:30:00', 'delivered',  37.48, '45 Le Loi',      'Da Nang', NULL, '550000', 'Vietnam'),
(3, 3, '2026-06-01 09:45:00', 'shipped',    99.98, '221 Market St',  'San Francisco', 'CA', '94105', 'USA'),
(4, 1, '2026-07-14 20:10:00', 'pending',    34.98, '12 Nguyen Trai', 'Hanoi',   NULL, '100000', 'Vietnam'),
(5, 4, '2026-08-05 13:00:00', 'delivered',  62.48, '10 Baker Street','London',  NULL, 'NW1 6XE', 'United Kingdom'),
(6, 5, '2026-09-18 17:25:00', 'processing', 97.97, 'Calle Mayor 8',  'Madrid',  NULL, '28013', 'Spain');

-- Order items (13). unit_price = price at time of purchase.
INSERT INTO order_items (order_id, book_id, quantity, unit_price) VALUES
(1, 1, 1, 14.99),
(1, 2, 1, 13.99),
(2, 3, 2, 12.99),
(2, 4, 1, 11.50),
(3, 5, 1, 39.99),
(3, 6, 1, 59.99),
(4, 7, 1, 18.99),
(4, 8, 1, 15.99),
(5, 4, 3, 11.50),
(5, 3, 1, 12.99),
(5, 1, 1, 14.99),
(6, 6, 1, 59.99),
(6, 7, 2, 18.99);

-- Reviews (10) - one review per customer per book
INSERT INTO reviews (book_id, customer_id, rating, comment, review_date) VALUES
(1, 1, 5, 'A masterpiece of world-building.', '2026-05-12 19:00:00'),
(2, 1, 4, 'Dense but groundbreaking.', '2026-05-14 21:30:00'),
(3, 2, 5, 'Perfect adventure story.', '2026-05-20 08:15:00'),
(4, 2, 4, 'Charming and fun to read.', '2026-05-22 12:00:00'),
(5, 3, 4, 'Clear explanations and good exercises.', '2026-06-10 16:40:00'),
(6, 3, 5, 'Essential reading for backend engineers.', '2026-06-15 10:05:00'),
(4, 4, 5, 'Bought copies for the whole family.', '2026-08-12 18:20:00'),
(3, 4, 4, 'A timeless classic.', '2026-08-13 09:50:00'),
(7, 1, 3, 'Interesting, though some claims feel broad.', '2026-07-25 22:10:00'),
(7, 5, 5, 'Thought-provoking and well written.', '2026-09-28 20:00:00');

-- =====================================================================
-- Quick sanity checks (optional)
-- =====================================================================
-- SELECT o.order_id, o.total_amount, SUM(oi.subtotal) AS items_total
--   FROM orders o JOIN order_items oi USING (order_id) GROUP BY o.order_id;
