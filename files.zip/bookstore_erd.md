# Online Bookstore – Entity-Relationship Diagram

Notation: `PK` primary key, `FK` foreign key, `UQ` unique, `NN` not null.
Crow's foot in text: `1` = exactly one, `N` = many (zero or more), `o` = optional.

## 1. Relationship Diagram

```
 ┌────────────┐ 1                    N ┌──────────────┐ N            N ┌────────────┐
 │ publishers │────────────────────────│    books     │════════════════│  authors   │
 └────────────┘  publishes             └──────────────┘  via           └────────────┘
                                         ║    │    │      book_authors
                                         ║    │    │
                      via book_categories║    │    │ 1
                                         ║ N  │    └────────────┐
                                  ┌────────────┐                │ N
                                  │ categories │◄─┐         ┌─────────┐ N        1 ┌───────────┐
                                  └────────────┘  │ self    │ reviews │────────────│ customers │
                                    parent 1:N ───┘         └─────────┘ written by └───────────┘
                                                                                          │ 1
              books 1 ──── N order_items N ──── 1 orders N ──────────────────────────────┘
                                                      places (customer 1 : N orders)
                                                      
 Junction tables: book_authors (books M:N authors)
                  book_categories (books M:N categories)
                  order_items (orders M:N books, with quantity & unit_price)
```

## 2. Entities and Attributes

### authors
| Column | Type | Key / Constraint |
|---|---|---|
| author_id | INT UNSIGNED AUTO_INCREMENT | **PK** |
| first_name | VARCHAR(60) | NN |
| last_name | VARCHAR(60) | NN |
| biography | TEXT | |
| nationality | VARCHAR(60) | |
| birth_date | DATE | |

### publishers
| Column | Type | Key / Constraint |
|---|---|---|
| publisher_id | INT UNSIGNED AUTO_INCREMENT | **PK** |
| name | VARCHAR(120) | NN, UQ |
| street, city, country | VARCHAR | |
| website | VARCHAR(255) | |

### categories
| Column | Type | Key / Constraint |
|---|---|---|
| category_id | INT UNSIGNED AUTO_INCREMENT | **PK** |
| name | VARCHAR(80) | NN, UQ |
| description | TEXT | |
| parent_category_id | INT UNSIGNED | **FK → categories.category_id** (ON DELETE SET NULL) |

### books
| Column | Type | Key / Constraint |
|---|---|---|
| book_id | INT UNSIGNED AUTO_INCREMENT | **PK** |
| isbn | CHAR(13) | NN, UQ |
| title | VARCHAR(200) | NN |
| publisher_id | INT UNSIGNED | **FK → publishers.publisher_id** (RESTRICT), NN |
| price | DECIMAL(8,2) | NN, CHECK > 0 |
| stock | INT | NN, DEFAULT 0, CHECK >= 0 |
| publication_date | DATE | |
| pages, language, description | SMALLINT / VARCHAR / TEXT | language DEFAULT 'English' |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP |

### book_authors (junction)
| Column | Type | Key / Constraint |
|---|---|---|
| book_id | INT UNSIGNED | **PK (composite), FK → books** (CASCADE) |
| author_id | INT UNSIGNED | **PK (composite), FK → authors** (CASCADE) |
| author_order | TINYINT | DEFAULT 1 |

### book_categories (junction)
| Column | Type | Key / Constraint |
|---|---|---|
| book_id | INT UNSIGNED | **PK (composite), FK → books** (CASCADE) |
| category_id | INT UNSIGNED | **PK (composite), FK → categories** (CASCADE) |

### customers
| Column | Type | Key / Constraint |
|---|---|---|
| customer_id | INT UNSIGNED AUTO_INCREMENT | **PK** |
| first_name, last_name | VARCHAR(60) | NN |
| email | VARCHAR(190) | NN, UQ |
| password_hash | VARCHAR(255) | NN |
| phone, street, city, state, postal_code, country | VARCHAR | |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP |

### orders
| Column | Type | Key / Constraint |
|---|---|---|
| order_id | INT UNSIGNED AUTO_INCREMENT | **PK** |
| customer_id | INT UNSIGNED | **FK → customers.customer_id** (RESTRICT), NN |
| order_date | DATETIME | NN, DEFAULT CURRENT_TIMESTAMP |
| status | ENUM('pending','processing','shipped','delivered','cancelled') | NN, DEFAULT 'pending' |
| total_amount | DECIMAL(10,2) | NN, DEFAULT 0, CHECK >= 0 |
| ship_street, ship_city, ship_postal_code, ship_country | VARCHAR | NN (ship_state optional) |

### order_items
| Column | Type | Key / Constraint |
|---|---|---|
| order_item_id | INT UNSIGNED AUTO_INCREMENT | **PK** |
| order_id | INT UNSIGNED | **FK → orders.order_id** (CASCADE), NN |
| book_id | INT UNSIGNED | **FK → books.book_id** (RESTRICT), NN |
| quantity | INT UNSIGNED | NN, DEFAULT 1, CHECK > 0 |
| unit_price | DECIMAL(8,2) | NN, CHECK > 0 (price at purchase time) |
| subtotal | DECIMAL(10,2) | GENERATED = quantity × unit_price |
| | | UQ (order_id, book_id) |

### reviews
| Column | Type | Key / Constraint |
|---|---|---|
| review_id | INT UNSIGNED AUTO_INCREMENT | **PK** |
| book_id | INT UNSIGNED | **FK → books.book_id** (CASCADE), NN |
| customer_id | INT UNSIGNED | **FK → customers.customer_id** (CASCADE), NN |
| rating | TINYINT | NN, CHECK BETWEEN 1 AND 5 |
| comment | TEXT | |
| review_date | DATETIME | NN, DEFAULT CURRENT_TIMESTAMP |
| | | UQ (customer_id, book_id) |

## 3. Relationships and Cardinality

| # | Relationship | Cardinality | Implemented by |
|---|---|---|---|
| 1 | publishers – books | **1:N** | books.publisher_id |
| 2 | books – authors | **M:N** | junction `book_authors` |
| 3 | books – categories | **M:N** | junction `book_categories` |
| 4 | categories – categories (parent/sub-genre) | **1:N** (self) | categories.parent_category_id |
| 5 | customers – orders | **1:N** | orders.customer_id |
| 6 | orders – books | **M:N** | junction `order_items` (adds quantity, unit_price) |
| 7 | orders – order_items | **1:N** | order_items.order_id |
| 8 | customers – reviews | **1:N** | reviews.customer_id |
| 9 | books – reviews | **1:N** | reviews.book_id |

## 4. ON DELETE / ON UPDATE Policy

| Foreign key | ON DELETE | Reason |
|---|---|---|
| books → publishers | RESTRICT | Don't delete a publisher that still has books |
| book_authors, book_categories → books/authors/categories | CASCADE | Link rows are meaningless without either side |
| categories.parent → categories | SET NULL | Sub-genre becomes top-level if parent is removed |
| orders → customers | RESTRICT | Preserve order history |
| order_items → orders | CASCADE | Deleting an order deletes its items |
| order_items → books | RESTRICT | Sold books must stay in the catalog |
| reviews → books / customers | CASCADE | Reviews depend on both |

All FKs use ON UPDATE CASCADE.

## 5. Why this is 3NF (example to point at in the video)

- **Publisher data**: `books` stores only `publisher_id`. The publisher's name, address and website depend on `publisher_id`, not on `book_id`, so they live in `publishers` (removes the transitive dependency book_id → publisher_id → publisher_name).
- **Authors/categories**: multi-valued facts are moved into junction tables (1NF) whose attributes depend on the whole composite key (2NF).
- **Snapshots**: `order_items.unit_price` and `orders.ship_*` record values as they were at purchase time, so they are independent facts, not duplicates of `books.price` or `customers.*`.
